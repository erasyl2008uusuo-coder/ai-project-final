# QAIRU AI Lab — Final Project 2026

Интерактивная веб-лаборатория по курсу **AI Fundamentals** (QAIRU). Алгоритмы написаны вручную на JavaScript, без готовых AI API.

## Реализованные темы
| Неделя | Тема | Где | Что можно менять |
|---|---|---|---|
| 2 | BFS, DFS, UCS, A* | Іздеу | алгоритм, стены, болота |
| 3 | Hill Climbing, Random Restart, Simulated Annealing | N ферзей | N, метод, restarts |
| 4 | Minimax, Alpha-Beta | Крестики-нолики | метод, ходы игрока |
| 6 | Naive Bayes | Фишинг-детектор | текст сообщения |

Есть AI Quiz по неделям 2–10 и система XP (localStorage).

## Запуск
```bash
python3 -m http.server 8000   # открыть http://localhost:8000
npm test                       # unit-тесты (Node 18+)
```
Модули ES требуют сервер, `index.html` двойным кликом не откроется.

## Публикация на GitHub Pages
Repo → Settings → Pages → Branch `main` / root.

## Структура
`index.html` · `css/style.css` · `js/algos.js` (алгоритмы) · `js/app.js` (интерфейс) · `tests/algos.test.js`

## Тестирование
12 тестов: оптимальность A*/UCS, отсутствие пути, блокировка выигрыша в Minimax, равный счёт Alpha-Beta при меньшем числе узлов, решение 8 ферзей, обработка неверного ввода.

## Ограничения
Эвристика A* — манхэттенское расстояние; Naive Bayes обучен на малом наборе (учебная демонстрация); SA/HC вероятностны, поэтому 100 запусков показывают статистику.

## Авторы
Erasyl Serik

*Вклад участников, AI Usage Declaration и скриншоты добавь перед сдачей.*
