import*as A from'./algos.js';
const $=s=>document.querySelector(s),view=$('#view');
const xp=()=>+localStorage.getItem('xp')||0;
const gain=n=>{localStorage.setItem('xp',xp()+n);showXp()};
const showXp=()=>$('#xp').textContent=`⚡ ${xp()} XP · Lv ${1+Math.floor(xp()/100)}`;
const say=(el,t,bad)=>{el.textContent=t;el.className='out'+(bad?' err':'')};

const MODS={
 search:{t:'Іздеу · Pathfinding',wk:'Week 2',d:'BFS, DFS, UCS и A* на сетке. Рисуй стены и болота, сравнивай алгоритмы.',run:search},
 queens:{t:'N ферзей',wk:'Week 3',d:'Hill Climbing, random restart и Simulated Annealing: кто решит доску?',run:queens},
 mm:{t:'Крестики-нолики',wk:'Week 4',d:'Сыграй против Minimax и Alpha-Beta и посмотри, сколько узлов они проверили.',run:ttt},
 bayes:{t:'Фишинг-детектор',wk:'Week 6',d:'Naive Bayes считает вероятность спама для твоего сообщения.',run:bayes},
 quiz:{t:'AI Quiz',wk:'Weeks 1–10',d:'Вопросы по всем темам курса. Правильный ответ даёт XP.',run:quiz}
};
const ICON={search:'🧭',queens:'♛',mm:'⭕',bayes:'🎣',quiz:'🧠'};
const CREATORS=[['Erasyl','E','Lead Developer','Алгоритмы поиска, Minimax, архитектура проекта'],['Serik','S','UI/UX & Testing','Дизайн интерфейса, unit-тесты и документация']];
const PAGES=['home','games','creators'];let landing=false;
const onScroll=()=>{const h=$('#s-home');if(h)h.style.setProperty('--p',Math.min(1,Math.max(0,scrollY/(innerHeight*.7))))};
function nav(){const h=location.hash.slice(1)||'home',pg=PAGES.includes(h);
 $('#nav').innerHTML=[['home','О проекте'],['games','Игры'],['creators','Creators']].map(([k,t])=>`<a href="#${k}" class="${pg&&h===k?'on':''}">${t}</a>`).join('');
 if(pg){const fresh=!landing||!$('#s-home');if(fresh)home();$('#s-'+h).scrollIntoView({behavior:fresh?'auto':'smooth'});landing=true}
 else{landing=false;(MODS[h]?.run||home)();view.insertAdjacentHTML('afterbegin','<a class=back href="#games">← К играм</a>');scrollTo(0,0)}}
function home(){let i=0;
 const T='AI Final Project'.split(' ').map(w=>`<span class=w>${[...w].map(c=>`<span class=l style="--i:${i};--r:${i++%2?9:-9}">${c}</span>`).join('')}</span>`).join(' ');
 view.innerHTML=`<section id=s-home class=hero><div class=stick><p class=kick>QAIRU · AI Fundamentals · 2026</p><h1 aria-label="AI Final Project">${T}</h1>
 <p class=lead>Рабочая лаборатория, где алгоритмы курса не только объясняют, но и запускают. Меняй параметры, смотри метрики и играй против ИИ, написанного с нуля.</p>
 <div class=pills><span>Поиск · Week 2</span><span>Local Search · Week 3</span><span>Minimax · Week 4</span><span>Bayes · Week 6</span></div>
 <a class=hint href="#games">Листай вниз ↓</a></div></section>
 <section id=s-games><h2>Выбери игру</h2><p class=d>Каждая игра — отдельная тема курса с живыми метриками.</p>
 <div class=grid>${Object.entries(MODS).map(([k,m])=>`<a class=gcard href="#${k}"><span class=ico>${ICON[k]}</span><span class=wk>${m.wk}</span><b>${m.t}</b><p>${m.d}</p><em>Играть</em></a>`).join('')}</div></section>
 <section id=s-creators><h2>Creators</h2><p class=d>Нажми на карточку, чтобы узнать роль в команде.</p>
 <div class=cg>${CREATORS.map(([n,a,r,t])=>`<button class=flip aria-label="${n}: показать роль"><span class=in><span class=f><i class=av>${a}</i><b>${n}</b><small>Нажми, чтобы повернуть</small></span><span class="f b"><b>${r}</b><small>${t}</small></span></span></button>`).join('')}</div></section>`;
 view.querySelectorAll('.flip').forEach(b=>b.onclick=()=>b.classList.toggle('on'));
 addEventListener('scroll',onScroll,{passive:true});onScroll()}

function search(){
 const R=14,C=28,Z=30,S=[1,1],T=[R-2,C-2];let g,vis=[],path=[],tm;
 const blank=()=>g=Array.from({length:R},()=>Array(C).fill(0));blank();
 view.innerHTML=`<h2>Іздеу · Pathfinding</h2><p class=d>Клик или drag — стена. Shift + клик — болото (цена 5).</p>
 <div class=row><select id=al aria-label="Алгоритм"><option value=bfs>BFS<option value=dfs>DFS<option value=ucs>UCS<option value=astar selected>A*</select>
 <button id=go>▶ Запустить</button><button id=mz>🎲 Случайная карта</button><button id=cl>Очистить</button></div>
 <canvas id=cv width=840 height=420></canvas><div class=out id=out>Выбери алгоритм и нажми «Запустить».</div>`;
 const cv=$('#cv'),x=cv.getContext('2d');
 const draw=(n=vis.length)=>{x.clearRect(0,0,840,420);
  for(let r=0;r<R;r++)for(let c=0;c<C;c++){x.fillStyle=['#10193f','#3a4a96','#8a6a20'][g[r][c]];x.fillRect(c*Z+1,r*Z+1,Z-2,Z-2)}
  x.fillStyle='#00afca99';vis.slice(0,n).forEach(([r,c])=>x.fillRect(c*Z+4,r*Z+4,Z-8,Z-8));
  if(n>=vis.length){x.fillStyle='#f6c343';path.forEach(([r,c])=>x.fillRect(c*Z+9,r*Z+9,Z-18,Z-18))}
  x.fillStyle='#5eead4';x.fillRect(S[1]*Z+3,S[0]*Z+3,Z-6,Z-6);x.fillStyle='#ff6b6b';x.fillRect(T[1]*Z+3,T[0]*Z+3,Z-6,Z-6)};
 const paint=e=>{const b=cv.getBoundingClientRect(),c=Math.floor((e.clientX-b.left)*840/b.width/Z),r=Math.floor((e.clientY-b.top)*420/b.height/Z);
  if(g[r]?.[c]===undefined||(r==S[0]&&c==S[1])||(r==T[0]&&c==T[1]))return;g[r][c]=e.shiftKey?2:1;vis=[];path=[];draw()};
 cv.onpointerdown=paint;cv.onpointermove=e=>e.buttons&&paint(e);
 $('#cl').onclick=()=>{clearInterval(tm);blank();vis=[];path=[];draw()};
 $('#mz').onclick=()=>{blank();for(let r=0;r<R;r++)for(let c=0;c<C;c++){const p=Math.random();g[r][c]=p<.27?1:p<.35?2:0}
  g[S[0]][S[1]]=g[T[0]][T[1]]=0;vis=[];path=[];draw()};
 $('#go').onclick=()=>{clearInterval(tm);const a=$('#al').value,t0=performance.now(),res=A.search(g,S,T,a),ms=(performance.now()-t0).toFixed(2);
  vis=res.order;path=res.path||[];let n=0;
  const why={bfs:'BFS идёт волнами и минимизирует число шагов, но игнорирует болота.',dfs:'DFS уходит вглубь: быстро, но путь обычно не оптимален.',ucs:'UCS расширяет самый дешёвый узел и учитывает цену болот.',astar:'A* = стоимость пути + эвристика (манхэттен): оптимален и проверяет меньше узлов.'}[a];
  const done=()=>{say($('#out'),path.length?`${a.toUpperCase()}: проверено узлов ${vis.length}, шагов ${path.length-1}, цена ${res.cost}, ${ms} мс\n${why}`:'Путь не найден: стены полностью перекрывают проход. Очисти часть карты.',!path.length);if(path.length)gain(5)};
  tm=setInterval(()=>{n+=4;draw(n);if(n>=vis.length){clearInterval(tm);done()}},16)};
 draw()}

function queens(){
 view.innerHTML=`<h2>N ферзей · Local Search</h2><p class=d>Hill Climbing застревает в локальных минимумах, restarts и Simulated Annealing помогают.</p>
 <div class=row><label>N <input id=n type=number value=8 min=4 max=16 style="width:70px"></label>
 <select id=m><option value=hc>Hill Climbing<option value=sa selected>Simulated Annealing</select>
 <label>Restarts <input id=rs type=number value=0 min=0 max=50 style="width:70px"></label>
 <button id=go>▶ Решить</button><button id=st class=g>📊 100 запусков</button></div>
 <div id=bd></div><div class=out id=out>Задай N и запусти.</div>`;
 const board=(q)=>{const n=q.length;$('#bd').innerHTML=`<div style="display:grid;grid-template-columns:repeat(${n},1fr);max-width:480px">${
  Array.from({length:n*n},(_,i)=>{const r=Math.floor(i/n),c=i%n;return`<div style="aspect-ratio:1;display:grid;place-items:center;background:${(r+c)%2?'#1b2a6b':'#0e1a46'}">${q[c]===r?'♛':''}</div>`}).join('')}</div>`};
 const args=()=>[+$('#n').value,$('#m').value,Math.random,+$('#rs').value];
 $('#go').onclick=()=>{try{const r=A.solveQueens(...args());board(r.q);
  say($('#out'),r.conflicts?`Застряли: конфликтов ${r.conflicts}, шагов ${r.steps}. Увеличь restarts или смени метод.`:`Решено! шагов ${r.steps}, перезапусков ${r.restarts}.`,!!r.conflicts);if(!r.conflicts)gain(10)}catch(e){say($('#out'),e.message,1)}};
 $('#st').onclick=()=>{try{let ok=0,s=0;for(let i=0;i<100;i++){const r=A.solveQueens(...args());ok+=!r.conflicts;s+=r.steps}
  say($('#out'),`Успех: ${ok}/100, среднее шагов: ${(s/100).toFixed(0)}`)}catch(e){say($('#out'),e.message,1)}}}

function ttt(){let b,over;
 view.innerHTML=`<h2>Крестики-нолики · Adversarial Search</h2><p class=d>Ты играешь X. ИИ (O) считает дерево игры.</p>
 <div class=row><select id=ab><option value=1>Alpha-Beta<option value=0>Minimax</select><button id=rs>Новая игра</button></div>
 <div class=ttt id=bd></div><div class=out id=out></div>`;
 const reset=()=>{b=Array(9).fill(null);over=0;say($('#out'),'Твой ход.');draw()};
 const draw=()=>$('#bd').innerHTML=b.map((v,i)=>`<button data-i=${i} aria-label="клетка ${i+1}">${v||''}</button>`).join('');
 const end=()=>{const w=A.winner(b);if(!w)return 0;over=1;
  const msg=w==='D'?'Ничья — идеальная игра.':w==='X'?'Ты победил!':'ИИ победил.';if(w==='D')gain(10);if(w==='X')gain(50);return msg};
 $('#bd').onclick=e=>{const i=e.target.dataset.i;if(over||i===undefined||b[i])return;b[i]='X';
  let m=end(),info='';if(!m){const ab=$('#ab').value==='1',r=A.bestMove(b,'O',ab),r2=A.bestMove([...b],'O',!ab);
   b[r.move]='O';info=`ИИ проверил ${r.nodes} узлов (${ab?'Alpha-Beta':'Minimax'}); другой метод: ${r2.nodes}.`;m=end()}
  draw();say($('#out'),(m?m+'\n':'Твой ход.\n')+info)};
 $('#rs').onclick=reset;reset()}

const DATA=[['win free prize now click here','spam'],['free money urgent claim your reward','spam'],['your account is blocked verify password now','spam'],['congratulations you won a gift card click link','spam'],['urgent: confirm bank card number','spam'],['выиграй приз бесплатно нажми сюда','spam'],['срочно подтвердите пароль по ссылке','spam'],['ваш аккаунт заблокирован перейдите по ссылке','spam'],
 ['meeting tomorrow at ten about the project','ham'],['please send the homework before lecture','ham'],['lunch with the team on friday','ham'],['here are the notes from today class','ham'],['напомню про лекцию завтра в девять','ham'],['отправь, пожалуйста, отчёт по практике','ham'],['увидимся в библиотеке после занятий','ham'],['спасибо за помощь с проектом','ham']];
function bayes(){const p=A.trainNB(DATA);
 view.innerHTML=`<h2>Фишинг-детектор · Naive Bayes</h2><p class=d>Модель обучена на ${DATA.length} коротких сообщениях (RU/EN). Это учебная демонстрация, не защита.</p>
 <textarea id=t rows=3 style="width:100%" placeholder="Вставь сообщение…"></textarea>
 <div class=row><button id=go>Проверить</button><button id=ex class=g>Пример</button></div>
 <div class=bar><i id=b style="width:0"></i></div><div class=out id=out>Введи текст и нажми «Проверить».</div>`;
 $('#ex').onclick=()=>$('#t').value='Срочно подтвердите пароль, иначе аккаунт будет заблокирован';
 $('#go').onclick=()=>{try{const s=p($('#t').value);$('#b').style.width=(s*100)+'%';
  say($('#out'),`P(спам) = ${(s*100).toFixed(1)}% → ${s>.5?'похоже на фишинг ⚠️':'выглядит безопасно ✅'}\nКак считает: log-приор класса + сумма log P(слово|класс), Laplace-сглаживание.`);gain(3)}catch(e){say($('#out'),e.message,1)}}}

const Q=[['Week 2','Какой алгоритм гарантирует оптимальный путь при допустимой эвристике?',['DFS','A*','Hill Climbing'],1],['Week 3','Что помогает Hill Climbing выйти из локального максимума?',['Random restart','Больше слоёв','Меньше данных'],0],['Week 4','Что делает Alpha-Beta?',['Обучает сеть','Отсекает ветки дерева игры','Сглаживает вероятности'],1],['Week 5','Q-learning — это…',['Обучение с подкреплением','Поиск в глубину','Байесовская сеть'],0],['Week 6','Теорема Байеса связывает…',['Градиент и вес','Апостериорную и априорную вероятности','Стоимость и эвристику'],1],['Week 7','HMM выводит…',['Скрытые состояния по наблюдениям','Цвет пикселей','Порядок узлов BFS'],0],['Week 9','Перцептрон обновляет веса, когда…',['Ответ верный','Ответ ошибочный','Всегда одинаково'],1],['Week 10','Prompt injection — это угроза для…',['LLM-приложений','Принтеров','Только A*'],0]];
function quiz(){let i=0,sc=0;
 const step=()=>{if(i>=Q.length){view.innerHTML=`<h2>AI Quiz</h2><div class=out>Результат: ${sc}/${Q.length}. ${sc>=6?'Отлично!':'Повтори темы и попробуй снова.'}</div><div class=row><button id=a>Ещё раз</button></div>`;$('#a').onclick=quiz;return}
  const[w,q,o]=Q[i];view.innerHTML=`<h2>AI Quiz</h2><span class=wk>${w}</span> ${i+1}/${Q.length}<h3>${q}</h3><div class=q>${o.map((t,k)=>`<button data-k=${k}>${t}</button>`).join('')}</div>`;
  view.querySelector('.q').onclick=e=>{const k=e.target.dataset.k;if(k===undefined)return;if(+k===Q[i][3]){sc++;gain(10)}i++;step()}};step()}

addEventListener('hashchange',nav);showXp();nav();
