// Чистые алгоритмы (без DOM) — их тестирует tests/algos.test.js
const N4=[[1,0],[-1,0],[0,1],[0,-1]];
/** Week 2. g: 0 — свободно, 1 — стена, 2 — болото (цена 5). algo: bfs|dfs|ucs|astar */
export function search(g,s,t,algo){
  if(!['bfs','dfs','ucs','astar'].includes(algo))throw new Error('Белгісіз алгоритм: '+algo);
  const R=g.length,C=g[0].length,K=(r,c)=>r*C+c,seen=new Set(),prev=new Map(),order=[];
  const h=(r,c)=>Math.abs(r-t[0])+Math.abs(c-t[1]);
  const open=[[0,0,s,-1]];
  while(open.length){
    let i=algo==='dfs'?open.length-1:0;
    if(algo==='ucs'||algo==='astar')open.forEach((o,j)=>{if(o[0]<open[i][0])i=j});
    const [,gc,[r,c],par]=open.splice(i,1)[0],k=K(r,c);
    if(seen.has(k))continue;seen.add(k);prev.set(k,par);order.push([r,c]);
    if(r===t[0]&&c===t[1]){const path=[];for(let x=k;x!==-1;x=prev.get(x))path.unshift([Math.floor(x/C),x%C]);return{path,order,cost:gc}}
    for(const[dr,dc]of N4){const a=r+dr,b=c+dc;if(a<0||b<0||a>=R||b>=C||g[a][b]===1||seen.has(K(a,b)))continue;
      const ng=gc+(g[a][b]===2?5:1);open.push([algo==='ucs'?ng:algo==='astar'?ng+h(a,b):0,ng,[a,b],k])}
  }
  return{path:null,order,cost:Infinity};
}
/** Week 4. Minimax + Alpha-Beta для крестиков-ноликов */
const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
export const winner=b=>{for(const[x,y,z]of L)if(b[x]&&b[x]===b[y]&&b[x]===b[z])return b[x];return b.includes(null)?null:'D'};
export function bestMove(b,me,ab=true){
  let nodes=0;const opp=p=>p==='X'?'O':'X';
  const mm=(p,al,be,d)=>{nodes++;const w=winner(b);if(w)return w==='D'?0:w===me?10-d:d-10;
    const max=p===me;let v=max?-99:99;
    for(let i=0;i<9;i++)if(!b[i]){b[i]=p;const s=mm(opp(p),al,be,d+1);b[i]=null;
      if(max){v=Math.max(v,s);al=Math.max(al,v)}else{v=Math.min(v,s);be=Math.min(be,v)}
      if(ab&&be<=al)break}
    return v};
  let move=-1,score=-99;
  for(let i=0;i<9;i++)if(!b[i]){b[i]=me;const s=mm(opp(me),-99,99,1);b[i]=null;if(s>score){score=s;move=i}}
  return{move,score,nodes};
}
/** Week 3. N ферзей: Hill Climbing (+random restart) и Simulated Annealing. q[col]=row */
export const conflicts=q=>{let c=0;for(let i=0;i<q.length;i++)for(let j=i+1;j<q.length;j++)if(q[i]===q[j]||Math.abs(q[i]-q[j])===j-i)c++;return c};
export function solveQueens(n,mode,rnd=Math.random,restarts=0){
  if(!Number.isInteger(n)||n<4||n>16)throw new Error('N 4 пен 16 аралығында болуы керек');
  let steps=0,q,used=0;
  for(;used<=restarts;used++){
    q=Array.from({length:n},()=>Math.floor(rnd()*n));let T=2;
    for(let it=0;it<3000&&conflicts(q);it++,steps++){
      if(mode==='sa'){const c=Math.floor(rnd()*n),q2=[...q];q2[c]=Math.floor(rnd()*n);const d=conflicts(q2)-conflicts(q);
        if(d<=0||rnd()<Math.exp(-d/T))q=q2;T=Math.max(.01,T*.995)}
      else{let best=conflicts(q),bc=-1,br=-1;
        for(let c=0;c<n;c++)for(let r=0;r<n;r++){if(r===q[c])continue;const o=q[c];q[c]=r;const v=conflicts(q);q[c]=o;if(v<best){best=v;bc=c;br=r}}
        if(bc<0)break;q[bc]=br}
    }
    if(!conflicts(q))break;
  }
  return{q,conflicts:conflicts(q),steps,restarts:Math.min(used,restarts)};
}
/** Week 6. Naive Bayes (Laplace smoothing), возвращает P(spam|text) */
export const tok=t=>(String(t).toLowerCase().match(/[\p{L}\d]+/gu)||[]);
export function trainNB(data){
  const cnt={spam:{},ham:{}},tot={spam:0,ham:0},n={spam:0,ham:0},V=new Set();
  for(const[t,y]of data){n[y]++;for(const w of tok(t)){cnt[y][w]=(cnt[y][w]||0)+1;tot[y]++;V.add(w)}}
  return text=>{const w=tok(text);if(!w.length)throw new Error('Мәтін бос — хабарлама енгізіңіз');
    const lp={};for(const y of['spam','ham']){lp[y]=Math.log(n[y]/(n.spam+n.ham));for(const x of w)lp[y]+=Math.log(((cnt[y][x]||0)+1)/(tot[y]+V.size))}
    const m=Math.max(lp.spam,lp.ham),a=Math.exp(lp.spam-m),b=Math.exp(lp.ham-m);return a/(a+b)};
}
