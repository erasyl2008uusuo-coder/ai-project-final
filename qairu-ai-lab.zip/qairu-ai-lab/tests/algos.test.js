import test from 'node:test';import assert from 'node:assert/strict';
import{search,bestMove,winner,conflicts,solveQueens,trainNB}from'../js/algos.js';
const open=()=>Array.from({length:6},()=>Array(6).fill(0));
const lcg=(s=7)=>()=>(s=(s*16807)%2147483647)/2147483647;
test('BFS: кратчайший путь на пустой сетке',()=>assert.equal(search(open(),[0,0],[5,5],'bfs').path.length-1,10));
test('A* и UCS: одинаковая цена, A* смотрит не больше узлов',()=>{
  const g=open();g[2][1]=g[2][2]=g[2][3]=2;const a=search(g,[0,0],[5,5],'astar'),u=search(g,[0,0],[5,5],'ucs');
  assert.equal(a.cost,u.cost);assert.ok(a.order.length<=u.order.length)});
test('Нет пути → path=null',()=>{const g=open();for(let r=0;r<6;r++)g[r][3]=1;assert.equal(search(g,[0,0],[5,5],'astar').path,null)});
test('Неверный алгоритм → ошибка',()=>assert.throws(()=>search(open(),[0,0],[1,1],'x')));
test('Minimax блокирует выигрыш соперника',()=>{const b=['X','X',null,null,'O',null,null,null,null];assert.equal(bestMove(b,'O').move,2)});
test('Alpha-Beta: тот же счёт, меньше узлов',()=>{const b=Array(9).fill(null);b[0]='X';
  const m=bestMove([...b],'O',false),a=bestMove([...b],'O',true);assert.equal(m.score,a.score);assert.ok(a.nodes<m.nodes)});
test('Пустая доска без победителя',()=>assert.equal(winner(Array(9).fill(null)),null));
test('conflicts: диагональ = конфликт',()=>assert.equal(conflicts([0,1]),1));
test('Simulated Annealing решает 8 ферзей',()=>assert.equal(solveQueens(8,'sa',lcg(3),5).conflicts,0));
test('Hill Climbing + restarts решает 8 ферзей',()=>assert.equal(solveQueens(8,'hc',lcg(5),30).conflicts,0));
test('N вне диапазона → ошибка',()=>assert.throws(()=>solveQueens(2,'sa')));
test('Naive Bayes: спам > обычное сообщение',()=>{
  const p=trainNB([['win free prize now','spam'],['free money click','spam'],['meeting at noon','ham'],['lunch tomorrow team','ham']]);
  assert.ok(p('free prize')>0.5&&p('team meeting')<0.5);assert.throws(()=>p('   '))});
